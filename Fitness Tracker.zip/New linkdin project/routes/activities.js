const express = require('express');
const router = express.Router();
const Activity = require('../models/Activity');

// Route to add a new activity
router.post('/add', async (req, res) => {
  const newActivity = new Activity(req.body);
  try {
    const savedActivity = await newActivity.save();
    res.json(savedActivity);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Route to get all activities
router.get('/', async (req, res) => {
  try {
    const activities = await Activity.find();
    res.json(activities);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;