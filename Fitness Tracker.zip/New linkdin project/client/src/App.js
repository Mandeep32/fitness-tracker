import React from 'react';
import ActivityForm from './components/ActivityForm';
import ActivityList from './components/ActivityList';
import ProgressChart from './components/ProgressChart';

function App() {
  return (
    <div>
      <h1>Fitness Tracker</h1>
      <ActivityForm />
      <ActivityList />
      <ProgressChart />
    </div>
  );
}

export default App;