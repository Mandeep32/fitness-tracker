// [ProgressChart.js](http://_vscodecontentref_/1)
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

function ProgressChart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const res = await axios.get('http://localhost:5000/activities');
        setData(res.data);
      } catch (error) {
        console.error('There was an error fetching the activities!', error);
      }
    };
    fetchActivities();
  }, []);

  return (
    <LineChart width={600} height={300} data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="date" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Line type="monotone" dataKey="duration" stroke="#8884d8" />
    </LineChart>
  );
}

export default ProgressChart;