import React, { useState } from 'react';
import axios from 'axios';

function ActivityForm() {
  const [type, setType] = useState('');
  const [duration, setDuration] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newActivity = { type, duration };
    try {
      await axios.post('http://localhost:5000/activities/add', newActivity);
      setType('');
      setDuration('');
    } catch (error) {
      console.error('There was an error adding the activity!', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={type}
        onChange={(e) => setType(e.target.value)}
        placeholder="Activity Type"
        required
      />
      <input
        type="number"
        value={duration}
        onChange={(e) => setDuration(e.target.value)}
        placeholder="Duration (minutes)"
        required
      />
      <button type="submit">Add Activity</button>
    </form>
  );
}

export default ActivityForm;