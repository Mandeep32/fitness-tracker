// [ActivityList.js](http://_vscodecontentref_/0)
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ActivityList() {
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const res = await axios.get('http://localhost:5000/activities');
        setActivities(res.data);
      } catch (error) {
        console.error('There was an error fetching the activities!', error);
      }
    };
    fetchActivities();
  }, []);

  return (
    <ul>
      {activities.map((activity) => (
        <li key={activity._id}>
          {activity.type} - {activity.duration} minutes
        </li>
      ))}
    </ul>
  );
}

export default ActivityList;