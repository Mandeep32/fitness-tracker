// [server.js](http://_vscodecontentref_/2)
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/fitness-tracker');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Import routes
const activityRoutes = require('./routes/activities');

// Use routes
app.use('/activities', activityRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});